<?php $__env->startSection('content'); ?>

  <!-- Image Showcases -->
  <section class="showcase">
        
        <div class="container-fluid p-0">
          <div class="row no-gutters">
    
            
            <div class="col-lg-12 order-lg-1 my-auto showcase-text">
              <h2>Perfil de Usuario</h2>
              <p class="lead mb-0">Edite su perfil!</p>
            </div>
          </div>
         
      </section>


      
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog_2\resources\views/genericuser/index.blade.php ENDPATH**/ ?>