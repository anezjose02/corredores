<?php $__env->startSection('content'); ?>

<h1> This is the profile of a corredor </h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog_2\resources\views/admin/profile.blade.php ENDPATH**/ ?>