@extends('layouts.app')
@section('content')

  <!-- Image Showcases -->
  <section class="showcase">
        
        <div class="container-fluid p-0">
          <div class="row no-gutters">
    
            
            <div class="col-lg-12 order-lg-1 my-auto showcase-text">
              <h2>Contact us</h2>
              <p class="lead mb-0">Contact us anytime!</p>
            </div>
          </div>
         
      </section>
    

@endsection