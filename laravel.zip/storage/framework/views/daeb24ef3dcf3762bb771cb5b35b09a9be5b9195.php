<?php if(session('success')): ?>
<div class="container">
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
</div>
<?php endif; ?>

<?php if(session('warning')): ?>
<div class="container">
<div class="alert alert-warning" role="alert">
        <?php echo e(session('warning')); ?>

    </div>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="container">
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('error')); ?>

    </div>
</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\blog_2\resources\views/partial/alerts.blade.php ENDPATH**/ ?>