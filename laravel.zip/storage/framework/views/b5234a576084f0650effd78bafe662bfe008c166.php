<?php $__env->startSection('content'); ?>
      <!-- DataTables Example -->
      <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Lista de corredores Naturales</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>      
                      <th>Id</th>
                      <th>Numero de Licencia</th>
                      <th>Reputacion</th>
                      <th>Nombre Idoneidad</th>
                      <th>Email</th>
                      <th>Fecha Emision</th>
                      <th>Fecha Vencimiento</th>
                      <th>Estado</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                            <th>Id</th>
                            <th>Numero de Licencia</th>
                            <th>Reputacion</th>
                            <th>Nombre Idoneidad</th>
                            <th>Email</th>
                            <th>Fecha Emision</th>
                            <th>Fecha Vencimiento</th>
                            <th>Estado</th>
                    </tr>
                  </tfoot>
                  <tbody>


                        <?php $__currentLoopData = $naturales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $natural): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($natural->id_natural); ?> </td>
                            <td><?php echo e($natural->no_lic_pn); ?> </td>
                            <td><?php echo e($natural->reputacion); ?> </td>
                            <td><?php echo e($natural->nombre_idoneidad); ?> </td>
                            <td><?php echo e($natural->email); ?> </td>
                            <td><?php echo e($natural->fecha_emision); ?> </td>
                            <td><?php echo e($natural->fecha_vencimiento); ?> </td>
                            <td><?php echo e($natural->status); ?> </td>

                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                   
                  
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog_2\resources\views/admin/naturales/index.blade.php ENDPATH**/ ?>