<?php $__env->startSection('content'); ?>
      <!-- DataTables Example -->
      <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Lista de corredores Juridicos</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                            
                      <th>Id</th>
                      <th>Numero de Licencia</th>
                      <th>Nombre Sociedad anonima</th>
                      <th>Fecha Emision</th>
                      <th>Fecha Vencimiento</th>
                      <th>Suspendido o Cancelado a la Fecha</th>
                      <th>Nombre Representante Legal</th>
                      <th>Email</th>
                      <th>Numero Licencia Persona Natural</th>
                      <th>Reputacion</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Id</th>
                      <th>Numero de Licencia</th>
                      <th>Nombre Sociedad anonima</th>
                      <th>Fecha Emision</th>
                      <th>Fecha Vencimiento</th>
                      <th>Suspendido o Cancelado a la Fecha</th>
                      <th>Nombre Representante Legal</th>
                      <th>Email</th>
                      <th>Numero Licencia Persona Natural</th>
                      <th>Reputacion</th>
                    </tr>
                  </tfoot>
                  <tbody>
                    
                        <?php $__currentLoopData = $juridicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juridico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($juridico->id_juridico); ?> </td>
                            <td><?php echo e($juridico->no_lic); ?> </td>
                            <td><?php echo e($juridico->nombre_sociedad_anonima); ?> </td>
                            <td><?php echo e($juridico->fecha_emision); ?> </td>
                            <td><?php echo e($juridico->fecha_vencimiento); ?> </td>
                            <td><?php echo e($juridico->suspendidos_cancel_hasta_la_fecha); ?> </td>
                            <td><?php echo e($juridico->nombre_representante_legal); ?> </td>
                            <td><?php echo e($juridico->email); ?> </td>
                            <td><?php echo e($juridico->no_lic_pn); ?> </td>
                            <td><?php echo e($juridico->reputacion); ?> </td>

                        </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                   
                  
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog_2\resources\views/admin/juridicos/index.blade.php ENDPATH**/ ?>